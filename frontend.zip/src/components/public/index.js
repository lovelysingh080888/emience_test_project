import React from 'react'
import "../common/style.css"
export const Home = () => {
  return (
    <div className='bg-image'>
      <div>
       <h1 style={{color:"#fff", alignItems:"center"}}>Welcome to Eminence</h1>
       <h3 style={{color:"#fff", textAlign:"center"}}>Home Page</h3>
      </div>
    </div>
  )
}
