# To install the package
Step 1. npm install

# Make sure backend server is running before starting the react server.

Step 2. npm start
